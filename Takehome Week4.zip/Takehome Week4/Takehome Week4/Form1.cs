﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Takehome_Week4
{
    public partial class Form1 : Form
    {
        DataTable dt_team = new DataTable();
        DataTable dt_country = new DataTable();
        DataTable dt_player = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {
         
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_position.Items.Add("GK");
            cb_position.Items.Add("DF");
            cb_position.Items.Add("MF");
            cb_position.Items.Add("FW");
            dt_country.Columns.Add("England");
            dt_country.Columns.Add("Germany");
            dt_country.Rows.Add("Manchester United", "Chelsea");
            dt_country.Rows.Add("Bayem Munich");

            dt_player.Columns.Add("Player Number");
            dt_player.Columns.Add("Player Name");
            dt_player.Columns.Add("Player Pos");
            dt_player.Rows.Add("05", "Harry Maguire", "DF");
            dt_player.Rows.Add("06", "Lisando Martinez", "DF");
            dt_player.Rows.Add("06", "Lisando Martinez", "DF");
            for (int i = 0; i < dt_country.Columns.Count; i++)
            {
                cb_country.Items.Add(dt_country.Columns[i].ToString());
            }
        }

        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {

            int i;
            for (i = 0; i < cb_country.Items.Count; i++)
            {
                if (cb_country.SelectedItem == dt_country.Columns[i].ToString())
                {
                    cb_team.Items.Clear();
                    for (int j = 0; j < dt_country.Columns.Count; j++)
                    {
                        cb_team.Items.Add(dt_country.Rows[i][j].ToString());
                    }
                }

            }
        }

            private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cb_team.SelectedItem == dt_country.Rows[0][0].ToString())
            {
                lb_team.Items.Clear();
                for (int i = 0;i < dt_team.Rows.Count; i++)
                {
                    lb_team.Items.Add(" (" + dt_player.Rows[i][0].ToString() + ") " + " " + dt_player.Rows[i][1].ToString() + " " + dt_player.Rows[i][2].ToString());
                }
                //lb_team.Items.Add(" (" + dt_player.Rows[i][0].ToString() + ") " + " " + dt_player.Rows[i][1].ToString() + " " + dt_player.Rows[i][2].ToString());

            }
        }

        private void bt_addteam_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dt_team.Rows.Count; i++)
            {
                if (tb_tname.Text == dt_team.Rows.ToString())
                {
                    MessageBox.Show("Error Same Team found");
                }
                else
                {
                    dt_team.Rows.Add(tb_tname.Text);
                }
            }
            
            dt_country.Columns.Add(tb_tcountry.Text);
           
                dt_country.Rows.Add(tb_tname.Text);

        }

        private void bt_addplayer_Click(object sender, EventArgs e)
        {

        }
    }
}
