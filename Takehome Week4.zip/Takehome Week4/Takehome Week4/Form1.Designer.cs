﻿namespace Takehome_Week4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_team = new System.Windows.Forms.ListBox();
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_tname = new System.Windows.Forms.TextBox();
            this.tb_tcountry = new System.Windows.Forms.TextBox();
            this.tb_tcity = new System.Windows.Forms.TextBox();
            this.bt_addteam = new System.Windows.Forms.Button();
            this.bt_addplayer = new System.Windows.Forms.Button();
            this.tb_pnumber = new System.Windows.Forms.TextBox();
            this.tb_pname = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cb_position = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.bt_remove = new System.Windows.Forms.Button();
            this.gb_team = new System.Windows.Forms.GroupBox();
            this.gb_player = new System.Windows.Forms.GroupBox();
            this.gb_team.SuspendLayout();
            this.gb_player.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Soccer Team List";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Choose Country :";
            // 
            // lb_team
            // 
            this.lb_team.FormattingEnabled = true;
            this.lb_team.ItemHeight = 16;
            this.lb_team.Location = new System.Drawing.Point(15, 179);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(217, 116);
            this.lb_team.TabIndex = 2;
            // 
            // cb_country
            // 
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Location = new System.Drawing.Point(130, 95);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(121, 24);
            this.cb_country.TabIndex = 3;
            this.cb_country.SelectedIndexChanged += new System.EventHandler(this.cb_country_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(130, 125);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(121, 24);
            this.cb_team.TabIndex = 4;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Choose Team :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(60, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Adding Team";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(80, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Adding Player";
            // 
            // tb_tname
            // 
            this.tb_tname.Location = new System.Drawing.Point(114, 76);
            this.tb_tname.Name = "tb_tname";
            this.tb_tname.Size = new System.Drawing.Size(114, 22);
            this.tb_tname.TabIndex = 8;
            // 
            // tb_tcountry
            // 
            this.tb_tcountry.Location = new System.Drawing.Point(114, 117);
            this.tb_tcountry.Name = "tb_tcountry";
            this.tb_tcountry.Size = new System.Drawing.Size(114, 22);
            this.tb_tcountry.TabIndex = 9;
            // 
            // tb_tcity
            // 
            this.tb_tcity.Location = new System.Drawing.Point(114, 160);
            this.tb_tcity.Name = "tb_tcity";
            this.tb_tcity.Size = new System.Drawing.Size(114, 22);
            this.tb_tcity.TabIndex = 10;
            // 
            // bt_addteam
            // 
            this.bt_addteam.Location = new System.Drawing.Point(125, 205);
            this.bt_addteam.Name = "bt_addteam";
            this.bt_addteam.Size = new System.Drawing.Size(75, 23);
            this.bt_addteam.TabIndex = 11;
            this.bt_addteam.Text = "Add";
            this.bt_addteam.UseVisualStyleBackColor = true;
            this.bt_addteam.Click += new System.EventHandler(this.bt_addteam_Click);
            // 
            // bt_addplayer
            // 
            this.bt_addplayer.Location = new System.Drawing.Point(121, 205);
            this.bt_addplayer.Name = "bt_addplayer";
            this.bt_addplayer.Size = new System.Drawing.Size(75, 23);
            this.bt_addplayer.TabIndex = 15;
            this.bt_addplayer.Text = "Add";
            this.bt_addplayer.UseVisualStyleBackColor = true;
            this.bt_addplayer.Click += new System.EventHandler(this.bt_addplayer_Click);
            // 
            // tb_pnumber
            // 
            this.tb_pnumber.Location = new System.Drawing.Point(110, 117);
            this.tb_pnumber.Name = "tb_pnumber";
            this.tb_pnumber.Size = new System.Drawing.Size(121, 22);
            this.tb_pnumber.TabIndex = 13;
            // 
            // tb_pname
            // 
            this.tb_pname.Location = new System.Drawing.Point(110, 76);
            this.tb_pname.Name = "tb_pname";
            this.tb_pname.Size = new System.Drawing.Size(121, 22);
            this.tb_pname.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 16);
            this.label6.TabIndex = 16;
            this.label6.Text = "Team Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 120);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 16);
            this.label7.TabIndex = 17;
            this.label7.Text = "Team Country:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 166);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 16);
            this.label8.TabIndex = 18;
            this.label8.Text = "Team City:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 79);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 16);
            this.label9.TabIndex = 19;
            this.label9.Text = "Player Name:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 16);
            this.label10.TabIndex = 20;
            this.label10.Text = "Player Number:";
            // 
            // cb_position
            // 
            this.cb_position.FormattingEnabled = true;
            this.cb_position.Location = new System.Drawing.Point(110, 158);
            this.cb_position.Name = "cb_position";
            this.cb_position.Size = new System.Drawing.Size(121, 24);
            this.cb_position.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 166);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 16);
            this.label11.TabIndex = 22;
            this.label11.Text = "Player Position:";
            // 
            // bt_remove
            // 
            this.bt_remove.Location = new System.Drawing.Point(15, 301);
            this.bt_remove.Name = "bt_remove";
            this.bt_remove.Size = new System.Drawing.Size(75, 23);
            this.bt_remove.TabIndex = 23;
            this.bt_remove.Text = "Remove";
            this.bt_remove.UseVisualStyleBackColor = true;
            // 
            // gb_team
            // 
            this.gb_team.Controls.Add(this.tb_tcountry);
            this.gb_team.Controls.Add(this.label4);
            this.gb_team.Controls.Add(this.tb_tname);
            this.gb_team.Controls.Add(this.tb_tcity);
            this.gb_team.Controls.Add(this.bt_addteam);
            this.gb_team.Controls.Add(this.label6);
            this.gb_team.Controls.Add(this.label8);
            this.gb_team.Controls.Add(this.label7);
            this.gb_team.Location = new System.Drawing.Point(296, 51);
            this.gb_team.Name = "gb_team";
            this.gb_team.Size = new System.Drawing.Size(243, 244);
            this.gb_team.TabIndex = 24;
            this.gb_team.TabStop = false;
            // 
            // gb_player
            // 
            this.gb_player.Controls.Add(this.label5);
            this.gb_player.Controls.Add(this.tb_pname);
            this.gb_player.Controls.Add(this.tb_pnumber);
            this.gb_player.Controls.Add(this.label11);
            this.gb_player.Controls.Add(this.bt_addplayer);
            this.gb_player.Controls.Add(this.cb_position);
            this.gb_player.Controls.Add(this.label9);
            this.gb_player.Controls.Add(this.label10);
            this.gb_player.Location = new System.Drawing.Point(585, 51);
            this.gb_player.Name = "gb_player";
            this.gb_player.Size = new System.Drawing.Size(256, 244);
            this.gb_player.TabIndex = 25;
            this.gb_player.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 583);
            this.Controls.Add(this.gb_player);
            this.Controls.Add(this.gb_team);
            this.Controls.Add(this.bt_remove);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_country);
            this.Controls.Add(this.lb_team);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gb_team.ResumeLayout(false);
            this.gb_team.PerformLayout();
            this.gb_player.ResumeLayout(false);
            this.gb_player.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lb_team;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_tname;
        private System.Windows.Forms.TextBox tb_tcountry;
        private System.Windows.Forms.TextBox tb_tcity;
        private System.Windows.Forms.Button bt_addteam;
        private System.Windows.Forms.Button bt_addplayer;
        private System.Windows.Forms.TextBox tb_pnumber;
        private System.Windows.Forms.TextBox tb_pname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cb_position;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button bt_remove;
        private System.Windows.Forms.GroupBox gb_team;
        private System.Windows.Forms.GroupBox gb_player;
    }
}

